﻿namespace A3
{
}

namespace A3
{


    public partial class ERDijagram
    {
    }
}
